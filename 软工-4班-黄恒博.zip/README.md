# My-First-Game-
This is my first game.

[我的库](https://github.com/SonwFish/My-First-Game-"库的链接")


*这是我第一次写README，有许多不足，还请多多指教！
此程序事根据学长提供基础代码，我再后续给改编而来。里面有很多不足，例如每有实现撤回功能，以及在第35关结束后，游戏将无法顺利退出这个BUG。
因时间限制来不及将代码修改完善，以后有时间把代码修改完善之后，将会再来更新此库。




这是游戏的开始界面
![](https://github.com/SonwFish/img-folder/blob/master/%E5%BC%80%E5%A7%8B%E7%95%8C%E9%9D%A2.png)

这是游戏选关卡时的画面
![](https://github.com/SonwFish/img-folder/blob/master/%E9%80%89%E5%85%B3%E7%95%8C%E9%9D%A2.png)

这是游戏界面
![](https://github.com/SonwFish/img-folder/blob/master/%E6%B8%B8%E6%88%8F%E7%95%8C%E9%9D%A2.png)

这是游戏的暂停画面
![](https://github.com/SonwFish/img-folder/blob/master/%E6%B8%B8%E6%88%8F%E4%B8%AD%E9%80%94%E6%9A%82%E5%81%9C%E7%94%BB%E9%9D%A2.png)

游戏使用了相对路径，保证了能在其他电脑上直接运行。
![](https://github.com/SonwFish/img-folder/blob/master/%E7%9B%B8%E5%AF%B9%E8%B7%AF%E5%BE%84%E7%9A%84%E4%BD%BF%E7%94%A8.png)
