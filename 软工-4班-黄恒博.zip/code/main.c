#include"function.h"

int main()
{
	init();

	mainloop();

	int gameloop(int level);

	Map* LoadMap(int level);

	return 0;
}